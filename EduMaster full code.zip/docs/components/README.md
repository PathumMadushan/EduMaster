# Components

This folder is reserved for future reusable UI components.

Current project files:
- Main HTML: ../index.html
- Styles: ../css/style.css
- JavaScript: ../js/maths.js
